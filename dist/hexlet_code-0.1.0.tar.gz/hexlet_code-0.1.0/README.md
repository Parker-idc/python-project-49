### Hexlet tests and linter status:
[![Actions Status](https://github.com/Parker-idc/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Parker-idc/python-project-49/actions)